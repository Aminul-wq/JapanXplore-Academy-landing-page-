
  # Landing Page Design for JapanXploreAcademy

  This is a code bundle for Landing Page Design for JapanXploreAcademy. The original project is available at https://www.figma.com/design/V54RbhI58gO8xWq81Rg2gu/Landing-Page-Design-for-JapanXploreAcademy.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  