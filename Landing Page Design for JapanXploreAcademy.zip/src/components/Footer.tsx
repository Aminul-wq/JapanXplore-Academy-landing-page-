import { motion } from "motion/react";
import { Facebook, Twitter, Instagram, Linkedin, Mail } from "lucide-react";

export function Footer() {
  const socialLinks = [
    { icon: Facebook, href: "https://www.facebook.com/search/top?q=japanxplore%20academy%20hady", label: "Facebook" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Mail, href: "mailto:contact@japanxploreacademy.com", label: "Email" },
  ];

  return (
    <footer className="bg-gradient-to-b from-purple-900 to-purple-950 text-white py-12 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-4"
          >
            <h3 className="text-2xl bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
              JapanXploreAcademy
            </h3>
            <p className="text-purple-200">
              Your trusted partner in mastering the Japanese language from N5 to N1.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <h4 className="text-lg text-purple-300">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#courses" className="text-purple-200 hover:text-white transition-colors duration-200">
                  Courses
                </a>
              </li>
              <li>
                <a href="#test" className="text-purple-200 hover:text-white transition-colors duration-200">
                  Practice Tests
                </a>
              </li>
              <li>
                <a href="#about" className="text-purple-200 hover:text-white transition-colors duration-200">
                  About Us
                </a>
              </li>
            </ul>
          </motion.div>

          {/* Social Media */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <h4 className="text-lg text-purple-300">Connect With Us</h4>
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  whileHover={{ scale: 1.2, y: -5 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-2 rounded-full bg-purple-800 hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 transition-all duration-300"
                >
                  <social.icon className="w-5 h-5" />
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent my-8"></div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row justify-between items-center gap-4 text-purple-300 text-sm"
        >
          <p>© 2025 Japan Xplore Academy. All rights reserved.</p>
          <p className="text-purple-400">
            Developed by <span className="bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">SOHAG</span>
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
