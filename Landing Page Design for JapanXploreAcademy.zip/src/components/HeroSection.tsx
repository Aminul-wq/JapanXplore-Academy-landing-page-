import { motion } from "motion/react";
import { Button } from "./ui/button";

export function HeroSection({
  onGetStarted,
}: {
  onGetStarted: () => void;
}) {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 py-12 overflow-hidden bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Copyright at top */}
      <div className="absolute top-4 left-4 md:top-8 md:left-8 text-sm text-gray-600">
        © Hady Sensei
      </div>

      {/* Hero Content */}
      <div className="container mx-auto max-w-7xl">
        <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Left: Japan Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-center md:justify-end"
          >
            <div className="relative w-full max-w-md">
              <img
                src="https://images.unsplash.com/photo-1698627124505-103cb28e56ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMGN1bHR1cmUlMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjE1ODY1NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Japan Culture"
                className="w-full h-auto rounded-2xl shadow-2xl"
              />
            </div>
          </motion.div>

          {/* Right: Japanese Phrases and CTA */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-6"
          >
            {/* Transparent colored box with Japanese phrases */}
            <div className="backdrop-blur-md bg-white/60 border border-white/40 rounded-2xl p-8 shadow-xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="space-y-4"
              >
                <h1 className="text-3xl md:text-4xl text-purple-900">
                  久しぶりだな皆さん
                </h1>
                <div className="h-px bg-gradient-to-r from-purple-300 to-pink-300 my-4"></div>
                <h2 className="text-2xl md:text-3xl text-pink-900">
                  今日も一日頑張りましょう
                </h2>
              </motion.div>
            </div>

            {/* Get Started Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="flex justify-center md:justify-start"
            >
              <Button
                size="lg"
                onClick={onGetStarted}
                className="group relative overflow-hidden bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-12 py-6 text-xl shadow-lg transition-all duration-300 hover:shadow-2xl hover:scale-105"
              >
                <span className="relative z-10">
                  Get Started
                </span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-pink-600 to-purple-600"
                  initial={{ x: "100%" }}
                  whileHover={{ x: 0 }}
                  transition={{ duration: 0.3 }}
                />
              </Button>
            </motion.div>

            {/* Decorative Elements */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="flex gap-4 justify-center md:justify-start text-sm text-gray-600"
            >
              <div className="backdrop-blur-sm bg-white/40 rounded-full px-4 py-2">
                N5 - N1 Levels
              </div>
              <div className="backdrop-blur-sm bg-white/40 rounded-full px-4 py-2">
                Complete Grammar
              </div>
              <div className="backdrop-blur-sm bg-white/40 rounded-full px-4 py-2">
                Interactive Tests
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Floating decorative elements */}
      <motion.div
        className="absolute top-20 right-20 w-20 h-20 bg-purple-300/20 rounded-full blur-xl"
        animate={{
          y: [0, -20, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 left-20 w-32 h-32 bg-pink-300/20 rounded-full blur-xl"
        animate={{
          y: [0, 20, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </section>
  );
}