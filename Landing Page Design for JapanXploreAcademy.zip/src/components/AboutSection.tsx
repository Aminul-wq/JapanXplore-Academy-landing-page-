import { motion } from "motion/react";
import { Card, CardContent } from "./ui/card";
import { GraduationCap, BookOpen, Award, Users } from "lucide-react";

export function AboutSection() {
  const features = [
    {
      icon: GraduationCap,
      title: "Expert Instruction",
      description: "Learn from experienced Japanese language teachers with proven methodologies",
    },
    {
      icon: BookOpen,
      title: "Comprehensive Curriculum",
      description: "Complete coverage from beginner (N5) to advanced (N1) levels",
    },
    {
      icon: Award,
      title: "JLPT Focused",
      description: "Specifically designed to help you pass the Japanese Language Proficiency Test",
    },
    {
      icon: Users,
      title: "Interactive Learning",
      description: "Engage with dynamic content, tests, and real-world examples",
    },
  ];

  return (
    <section id="about" className="py-20 px-4 bg-gradient-to-b from-white to-purple-50">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            About JapanXploreAcademy
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            JapanXploreAcademy is dedicated to helping students master the Japanese language efficiently, 
            from beginner (N5) to advanced (N1) levels.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="backdrop-blur-md bg-white/60 border-white/40 shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600">
                      <feature.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl mb-2 text-gray-800">{feature.title}</h3>
                      <p className="text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="backdrop-blur-md bg-white/60 border border-white/40 rounded-2xl p-8 shadow-xl"
        >
          <div className="max-w-4xl mx-auto space-y-6">
            <h3 className="text-2xl text-center mb-6 text-gray-800">Our Mission</h3>
            <p className="text-gray-700 leading-relaxed">
              At JapanXploreAcademy, we believe that learning Japanese should be accessible, 
              comprehensive, and engaging. Our platform provides a structured pathway through all 
              JLPT levels, ensuring that students have access to complete grammar lists, extensive 
              kanji databases, and practical tense applications.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Whether you're just starting your Japanese language journey at N5 or preparing for 
              the advanced N1 examination, our resources are designed to support your learning 
              every step of the way. Each level includes detailed grammar explanations, comprehensive 
              kanji coverage with contextual meanings, and tense forms with real Japanese examples.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Our interactive test system provides dynamic practice questions that help reinforce 
              your learning and prepare you for actual JLPT examinations. Each test attempt presents 
              different questions, ensuring varied practice and comprehensive coverage of each level's 
              material.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
