import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "./ui/hover-card";
import { ScrollArea } from "./ui/scroll-area";
import { Badge } from "./ui/badge";
import { courseData, KanjiItem, TenseItem } from "../data/courseData";
import { ChevronRight } from "lucide-react";

export function CourseSection() {
  const [selectedLevel, setSelectedLevel] = useState("N5");
  const [selectedSubsection, setSelectedSubsection] = useState<"grammar" | "kanji" | "tense">("grammar");
  const [selectedTense, setSelectedTense] = useState<TenseItem | null>(null);

  const currentCourse = courseData.find(course => course.level === selectedLevel);

  return (
    <section id="courses" className="py-20 px-4 bg-gradient-to-b from-white to-purple-50">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            JLPT Course Levels
          </h2>
          <p className="text-xl text-gray-600">
            Comprehensive Japanese Language Proficiency Test preparation
          </p>
        </motion.div>

        <Tabs value={selectedLevel} onValueChange={setSelectedLevel} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8 bg-white/60 backdrop-blur-md p-2 rounded-xl shadow-lg">
            {courseData.map((course) => (
              <TabsTrigger
                key={course.level}
                value={course.level}
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white transition-all duration-300 hover:scale-105"
              >
                {course.level}
              </TabsTrigger>
            ))}
          </TabsList>

          {courseData.map((course) => (
            <TabsContent key={course.level} value={course.level} className="space-y-6">
              {/* Subsection Tabs */}
              <div className="grid grid-cols-3 gap-4 mb-8">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedSubsection("grammar");
                    setSelectedTense(null);
                  }}
                  className={`p-6 rounded-xl backdrop-blur-md border transition-all duration-300 ${
                    selectedSubsection === "grammar"
                      ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white border-transparent shadow-xl"
                      : "bg-white/60 border-white/40 text-gray-700 hover:border-purple-300"
                  }`}
                >
                  <h3 className="text-xl mb-2">Grammar</h3>
                  <p className={`text-sm ${selectedSubsection === "grammar" ? "text-white/90" : "text-gray-500"}`}>
                    {course.grammar.length} items
                  </p>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedSubsection("kanji");
                    setSelectedTense(null);
                  }}
                  className={`p-6 rounded-xl backdrop-blur-md border transition-all duration-300 ${
                    selectedSubsection === "kanji"
                      ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white border-transparent shadow-xl"
                      : "bg-white/60 border-white/40 text-gray-700 hover:border-purple-300"
                  }`}
                >
                  <h3 className="text-xl mb-2">Kanji</h3>
                  <p className={`text-sm ${selectedSubsection === "kanji" ? "text-white/90" : "text-gray-500"}`}>
                    {course.kanji.length} characters
                  </p>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedSubsection("tense");
                    setSelectedTense(null);
                  }}
                  className={`p-6 rounded-xl backdrop-blur-md border transition-all duration-300 ${
                    selectedSubsection === "tense"
                      ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white border-transparent shadow-xl"
                      : "bg-white/60 border-white/40 text-gray-700 hover:border-purple-300"
                  }`}
                >
                  <h3 className="text-xl mb-2">Tenses</h3>
                  <p className={`text-sm ${selectedSubsection === "tense" ? "text-white/90" : "text-gray-500"}`}>
                    {course.tenses.length} forms
                  </p>
                </motion.button>
              </div>

              {/* Content Display */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedSubsection}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {selectedSubsection === "grammar" && (
                    <Card className="backdrop-blur-md bg-white/60 border-white/40 shadow-xl">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <span className="text-2xl">Grammar Points - {course.level}</span>
                          <Badge variant="secondary">{course.grammar.length} items</Badge>
                        </CardTitle>
                        <CardDescription>Complete list of grammar patterns for this level</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ScrollArea className="h-[500px] pr-4">
                          <div className="grid md:grid-cols-2 gap-3">
                            {course.grammar.map((item, index) => (
                              <motion.div
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.02 }}
                                className="p-4 rounded-lg bg-white/80 border border-purple-200 hover:border-purple-400 hover:shadow-md transition-all duration-200"
                              >
                                <div className="flex items-start gap-2">
                                  <ChevronRight className="w-4 h-4 text-purple-600 mt-1 flex-shrink-0" />
                                  <p className="text-gray-700">{item}</p>
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  )}

                  {selectedSubsection === "kanji" && (
                    <Card className="backdrop-blur-md bg-white/60 border-white/40 shadow-xl">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <span className="text-2xl">Kanji Characters - {course.level}</span>
                          <Badge variant="secondary">{course.kanji.length} characters</Badge>
                        </CardTitle>
                        <CardDescription>Hover over each kanji to see meaning and related grammar</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ScrollArea className="h-[500px] pr-4">
                          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3">
                            {course.kanji.map((kanji, index) => (
                              <HoverCard key={index} openDelay={100}>
                                <HoverCardTrigger asChild>
                                  <motion.div
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ delay: index * 0.01 }}
                                    className="aspect-square flex items-center justify-center text-3xl bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border-2 border-purple-200 hover:border-purple-500 hover:shadow-lg transition-all duration-200 cursor-pointer hover:scale-110"
                                  >
                                    {kanji.character}
                                  </motion.div>
                                </HoverCardTrigger>
                                <HoverCardContent className="w-80 bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                                  <div className="space-y-2">
                                    <h4 className="text-4xl text-center text-purple-900 mb-3">{kanji.character}</h4>
                                    <div className="space-y-1">
                                      <p className="text-sm">
                                        <span className="text-purple-700">意味:</span> {kanji.meaning}
                                      </p>
                                      <p className="text-sm">
                                        <span className="text-pink-700">文法:</span> {kanji.relatedGrammar}
                                      </p>
                                    </div>
                                  </div>
                                </HoverCardContent>
                              </HoverCard>
                            ))}
                          </div>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  )}

                  {selectedSubsection === "tense" && (
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Tense List */}
                      <Card className="backdrop-blur-md bg-white/60 border-white/40 shadow-xl">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <span className="text-2xl">Tense Forms - {course.level}</span>
                            <Badge variant="secondary">{course.tenses.length} forms</Badge>
                          </CardTitle>
                          <CardDescription>Click a tense to view examples</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <ScrollArea className="h-[500px] pr-4">
                            <div className="space-y-2">
                              {course.tenses.map((tense, index) => (
                                <motion.button
                                  key={index}
                                  initial={{ opacity: 0, x: -20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: index * 0.05 }}
                                  onClick={() => setSelectedTense(tense)}
                                  className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                                    selectedTense?.name === tense.name
                                      ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg scale-105"
                                      : "bg-white/80 border border-purple-200 hover:border-purple-400 hover:shadow-md"
                                  }`}
                                >
                                  <div className="flex items-center justify-between">
                                    <span>{tense.name}</span>
                                    <ChevronRight className={`w-5 h-5 transition-transform ${
                                      selectedTense?.name === tense.name ? "rotate-90" : ""
                                    }`} />
                                  </div>
                                </motion.button>
                              ))}
                            </div>
                          </ScrollArea>
                        </CardContent>
                      </Card>

                      {/* Tense Examples */}
                      <Card className="backdrop-blur-md bg-white/60 border-white/40 shadow-xl">
                        <CardHeader>
                          <CardTitle className="text-2xl">Examples</CardTitle>
                          <CardDescription>
                            {selectedTense ? selectedTense.name : "Select a tense to view examples"}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <ScrollArea className="h-[500px] pr-4">
                            {selectedTense ? (
                              <div className="space-y-4">
                                {selectedTense.examples.map((example, index) => (
                                  <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200"
                                  >
                                    <p className="text-gray-800 leading-relaxed">{example}</p>
                                  </motion.div>
                                ))}
                              </div>
                            ) : (
                              <div className="flex items-center justify-center h-full text-gray-400">
                                <p>← Select a tense from the list to view examples</p>
                              </div>
                            )}
                          </ScrollArea>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
