import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Card, CardContent } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { testData, TestQuestion } from "../data/testData";
import { CheckCircle2, XCircle, Trophy, RefreshCw } from "lucide-react";

export function TestSection() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState<number[]>([]);
  const [testCompleted, setTestCompleted] = useState(false);
  const [currentTestSet, setCurrentTestSet] = useState<TestQuestion[]>([]);

  const startTest = (level: string) => {
    const levelData = testData.find(t => t.level === level);
    if (levelData) {
      const randomSetIndex = Math.floor(Math.random() * levelData.questions.length);
      const selectedSet = levelData.questions[randomSetIndex];
      
      setSelectedLevel(level);
      setCurrentTestSet(selectedSet);
      setCurrentQuestionIndex(0);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setScore(0);
      setAnsweredQuestions([]);
      setTestCompleted(false);
    }
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (showExplanation) return;
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    const currentQuestion = currentTestSet[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

    if (isCorrect) {
      setScore(score + 1);
    }

    setAnsweredQuestions([...answeredQuestions, selectedAnswer]);
    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentTestSet.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setTestCompleted(true);
    }
  };

  const handleRetakeTest = () => {
    if (selectedLevel) {
      startTest(selectedLevel);
    }
  };

  const currentQuestion = currentTestSet[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / currentTestSet.length) * 100;

  return (
    <section id="test" className="py-20 px-4 bg-gradient-to-b from-purple-50 to-white">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Test Your Knowledge
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Challenge yourself with practice tests for each level
          </p>

          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              size="lg"
              onClick={() => setIsDialogOpen(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-12 py-6 text-xl shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              Give a Test
            </Button>
          </motion.div>
        </motion.div>

        {/* Level Selection Dialog */}
        <Dialog open={isDialogOpen && !selectedLevel} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 to-pink-50">
            <DialogHeader>
              <DialogTitle className="text-2xl">Choose Your Level</DialogTitle>
              <DialogDescription>
                Select a JLPT level to start your practice test
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-5 gap-3 mt-4">
              {testData.map((level) => (
                <motion.button
                  key={level.level}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    startTest(level.level);
                    setIsDialogOpen(false);
                  }}
                  className="aspect-square flex items-center justify-center text-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-xl transition-all duration-300"
                >
                  {level.level}
                </motion.button>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* Test Dialog */}
        <Dialog open={selectedLevel !== null} onOpenChange={(open) => {
          if (!open) {
            setSelectedLevel(null);
            setIsDialogOpen(false);
          }
        }}>
          <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-purple-50 to-pink-50">
            {!testCompleted ? (
              <>
                <DialogHeader>
                  <div className="flex items-center justify-between mb-4">
                    <DialogTitle className="text-2xl">
                      {selectedLevel} Practice Test
                    </DialogTitle>
                    <Badge variant="secondary" className="text-lg px-4 py-2">
                      Question {currentQuestionIndex + 1} / {currentTestSet.length}
                    </Badge>
                  </div>
                  <Progress value={progress} className="h-2" />
                </DialogHeader>

                <AnimatePresence mode="wait">
                  {currentQuestion && (
                    <motion.div
                      key={currentQuestionIndex}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-6 mt-6"
                    >
                      {/* Question */}
                      <Card className="backdrop-blur-md bg-white/80 border-purple-200">
                        <CardContent className="p-6">
                          <p className="text-2xl text-gray-800 text-center">
                            {currentQuestion.question}
                          </p>
                        </CardContent>
                      </Card>

                      {/* Options */}
                      <div className="grid grid-cols-1 gap-3">
                        {currentQuestion.options.map((option, index) => {
                          const isSelected = selectedAnswer === index;
                          const isCorrect = index === currentQuestion.correctAnswer;
                          const showResult = showExplanation;

                          let buttonClass = "bg-white/80 border-purple-200 hover:border-purple-400 text-gray-800";
                          
                          if (showResult) {
                            if (isCorrect) {
                              buttonClass = "bg-green-100 border-green-500 text-green-900";
                            } else if (isSelected && !isCorrect) {
                              buttonClass = "bg-red-100 border-red-500 text-red-900";
                            }
                          } else if (isSelected) {
                            buttonClass = "bg-gradient-to-r from-purple-600 to-pink-600 border-transparent text-white";
                          }

                          return (
                            <motion.button
                              key={index}
                              whileHover={{ scale: showExplanation ? 1 : 1.02 }}
                              whileTap={{ scale: showExplanation ? 1 : 0.98 }}
                              onClick={() => handleAnswerSelect(index)}
                              disabled={showExplanation}
                              className={`p-4 rounded-lg border-2 transition-all duration-200 text-left flex items-center justify-between ${buttonClass}`}
                            >
                              <span className="text-lg">{option}</span>
                              {showResult && isCorrect && (
                                <CheckCircle2 className="w-6 h-6 text-green-600" />
                              )}
                              {showResult && isSelected && !isCorrect && (
                                <XCircle className="w-6 h-6 text-red-600" />
                              )}
                            </motion.button>
                          );
                        })}
                      </div>

                      {/* Explanation */}
                      <AnimatePresence>
                        {showExplanation && (
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                          >
                            <Card className="backdrop-blur-md bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
                              <CardContent className="p-6">
                                <h4 className="text-lg mb-2 text-blue-900">Explanation:</h4>
                                <p className="text-gray-700">{currentQuestion.explanation}</p>
                              </CardContent>
                            </Card>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Action Buttons */}
                      <div className="flex justify-end gap-3">
                        {!showExplanation ? (
                          <Button
                            onClick={handleSubmitAnswer}
                            disabled={selectedAnswer === null}
                            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8"
                          >
                            Submit Answer
                          </Button>
                        ) : (
                          <Button
                            onClick={handleNextQuestion}
                            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8"
                          >
                            {currentQuestionIndex < currentTestSet.length - 1 ? "Next Question" : "View Results"}
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            ) : (
              /* Test Results */
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center space-y-6 py-8"
              >
                <Trophy className="w-24 h-24 mx-auto text-yellow-500" />
                <h2 className="text-3xl">Test Completed!</h2>
                <div className="backdrop-blur-md bg-white/80 border-2 border-purple-200 rounded-2xl p-8 space-y-4">
                  <p className="text-6xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {score} / {currentTestSet.length}
                  </p>
                  <p className="text-2xl text-gray-700">
                    {Math.round((score / currentTestSet.length) * 100)}% Correct
                  </p>
                  <Progress 
                    value={(score / currentTestSet.length) * 100} 
                    className="h-4"
                  />
                </div>
                <div className="flex gap-4 justify-center">
                  <Button
                    onClick={handleRetakeTest}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Retake Test
                  </Button>
                  <Button
                    onClick={() => {
                      setSelectedLevel(null);
                      setIsDialogOpen(false);
                    }}
                    variant="outline"
                    className="px-8"
                  >
                    Close
                  </Button>
                </div>
              </motion.div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
