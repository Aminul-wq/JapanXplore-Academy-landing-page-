import { HeroSection } from "./components/HeroSection";
import { CourseSection } from "./components/CourseSection";
import { TestSection } from "./components/TestSection";
import { AboutSection } from "./components/AboutSection";
import { Footer } from "./components/Footer";

export default function App() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen">
      <HeroSection onGetStarted={() => scrollToSection("courses")} />
      <CourseSection />
      <TestSection />
      <AboutSection />
      <Footer />
    </div>
  );
}
