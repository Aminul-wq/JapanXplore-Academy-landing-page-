export interface TestQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface LevelTest {
  level: string;
  questions: TestQuestion[][];
}

export const testData: LevelTest[] = [
  {
    level: "N5",
    questions: [
      // Set 1
      [
        {
          id: 1,
          question: "私___学生です。",
          options: ["が", "は", "を", "に"],
          correctAnswer: 1,
          explanation: "「は」is the topic marker used here."
        },
        {
          id: 2,
          question: "毎日図書館___行きます。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 2,
          explanation: "「に」indicates direction/destination."
        },
        {
          id: 3,
          question: "これ___私の本です。",
          options: ["は", "が", "を", "の"],
          correctAnswer: 0,
          explanation: "「は」is used as the topic marker."
        },
        {
          id: 4,
          question: "昨日映画___見ました。",
          options: ["が", "は", "を", "に"],
          correctAnswer: 2,
          explanation: "「を」marks the direct object."
        },
        {
          id: 5,
          question: "日本語___話します。",
          options: ["が", "を", "は", "で"],
          correctAnswer: 1,
          explanation: "「を」is used with the verb 話す."
        }
      ],
      // Set 2
      [
        {
          id: 1,
          question: "公園___散歩します。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 3,
          explanation: "「で」indicates location of action."
        },
        {
          id: 2,
          question: "友達___会いました。",
          options: ["が", "を", "に", "と"],
          correctAnswer: 2,
          explanation: "「に」is used with the verb 会う."
        },
        {
          id: 3,
          question: "朝ご飯___食べます。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 1,
          explanation: "「を」marks the direct object."
        },
        {
          id: 4,
          question: "先生___質問します。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "「に」indicates the person to whom you ask."
        },
        {
          id: 5,
          question: "駅___近いです。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 0,
          explanation: "「が」is used with adjectives."
        }
      ],
      // Set 3
      [
        {
          id: 1,
          question: "週末___何をしますか。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 2,
          explanation: "「に」marks time expressions."
        },
        {
          id: 2,
          question: "ペン___書きます。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 3,
          explanation: "「で」indicates means/tool."
        },
        {
          id: 3,
          question: "テレビ___見ています。",
          options: ["が", "を", "に", "で"],
          correctAnswer: 1,
          explanation: "「を」is used with 見る."
        },
        {
          id: 4,
          question: "明日___行きません。",
          options: ["が", "を", "に", "は"],
          correctAnswer: 3,
          explanation: "「は」emphasizes the negative."
        },
        {
          id: 5,
          question: "部屋___きれいです。",
          options: ["が", "を", "に", "は"],
          correctAnswer: 0,
          explanation: "「が」is used with adjectives."
        }
      ]
    ]
  },
  {
    level: "N4",
    questions: [
      // Set 1
      [
        {
          id: 1,
          question: "雨が___たら、行きません。",
          options: ["降る", "降り", "降っ", "降った"],
          correctAnswer: 2,
          explanation: "The たら conditional uses the て-form stem."
        },
        {
          id: 2,
          question: "日本語が話せる___なりました。",
          options: ["ように", "ような", "ように", "ような"],
          correctAnswer: 0,
          explanation: "ようになる indicates a change in ability."
        },
        {
          id: 3,
          question: "宿題を___おきます。",
          options: ["して", "した", "する", "し"],
          correctAnswer: 0,
          explanation: "ておく indicates doing in advance."
        },
        {
          id: 4,
          question: "この本は読み___です。",
          options: ["やすい", "やすく", "やすくて", "やすいな"],
          correctAnswer: 0,
          explanation: "やすい attaches directly to verb stem."
        },
        {
          id: 5,
          question: "音楽を___ながら勉強します。",
          options: ["聞く", "聞き", "聞いて", "聞いた"],
          correctAnswer: 1,
          explanation: "ながら attaches to verb stem."
        }
      ],
      // Set 2
      [
        {
          id: 1,
          question: "友達に本を___もらいました。",
          options: ["貸して", "貸す", "貸し", "貸した"],
          correctAnswer: 0,
          explanation: "てもらう uses the て-form."
        },
        {
          id: 2,
          question: "食べ___です。",
          options: ["すぎ", "すぎる", "すぎた", "すぎて"],
          correctAnswer: 0,
          explanation: "すぎ is the noun form of すぎる."
        },
        {
          id: 3,
          question: "日本に行った___があります。",
          options: ["の", "こと", "もの", "ところ"],
          correctAnswer: 1,
          explanation: "ことがある indicates past experience."
        },
        {
          id: 4,
          question: "試験に合格する___です。",
          options: ["つもり", "はず", "よう", "そう"],
          correctAnswer: 0,
          explanation: "つもり indicates intention."
        },
        {
          id: 5,
          question: "雨が降り___になりました。",
          options: ["そう", "よう", "みたい", "らしい"],
          correctAnswer: 0,
          explanation: "そう indicates appearance of change."
        }
      ],
      // Set 3
      [
        {
          id: 1,
          question: "泳げる___できますか。",
          options: ["こと", "の", "よう", "ところ"],
          correctAnswer: 0,
          explanation: "ことができる expresses ability."
        },
        {
          id: 2,
          question: "忙しい___、手伝います。",
          options: ["けど", "が", "のに", "から"],
          correctAnswer: 2,
          explanation: "のに expresses contrast despite."
        },
        {
          id: 3,
          question: "静かに___ください。",
          options: ["して", "する", "した", "し"],
          correctAnswer: 0,
          explanation: "てください uses the て-form."
        },
        {
          id: 4,
          question: "彼は来る___しれません。",
          options: ["かも", "はず", "つもり", "そう"],
          correctAnswer: 0,
          explanation: "かもしれない expresses possibility."
        },
        {
          id: 5,
          question: "勉強する___に図書館へ行きます。",
          options: ["ため", "よう", "こと", "の"],
          correctAnswer: 0,
          explanation: "ために indicates purpose."
        }
      ]
    ]
  },
  {
    level: "N3",
    questions: [
      // Set 1
      [
        {
          id: 1,
          question: "この問題___について議論しました。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "について means 'about/regarding'."
        },
        {
          id: 2,
          question: "彼の意見___対して反対しました。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に対して means 'towards/against'."
        },
        {
          id: 3,
          question: "努力した___、合格しました。",
          options: ["おかげで", "せいで", "ために", "ので"],
          correctAnswer: 0,
          explanation: "おかげで indicates positive result."
        },
        {
          id: 4,
          question: "雨が降る___にかかわらず、行きます。",
          options: ["こと", "の", "もの", "ところ"],
          correctAnswer: 1,
          explanation: "にかかわらず means 'regardless of'."
        },
        {
          id: 5,
          question: "彼___とって、これは重要です。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "にとって means 'for/to someone'."
        }
      ],
      // Set 2
      [
        {
          id: 1,
          question: "気温が上がる___つれて、暑くなります。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "につれて indicates proportional change."
        },
        {
          id: 2,
          question: "簡単___わけではありません。",
          options: ["の", "な", "だ", "である"],
          correctAnswer: 1,
          explanation: "わけではない with な-adjectives uses な."
        },
        {
          id: 3,
          question: "行かない___をえません。",
          options: ["わけ", "はず", "ざる", "こと"],
          correctAnswer: 2,
          explanation: "ざるをえない means 'cannot help but'."
        },
        {
          id: 4,
          question: "学生___べきことです。",
          options: ["が", "に", "の", "を"],
          correctAnswer: 0,
          explanation: "べき means 'should/ought to'."
        },
        {
          id: 5,
          question: "彼は遅刻___がちです。",
          options: ["な", "の", "だ", "し"],
          correctAnswer: 3,
          explanation: "がち attaches to verb stem."
        }
      ],
      // Set 3
      [
        {
          id: 1,
          question: "このデータ___基づいて報告します。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に基づいて means 'based on'."
        },
        {
          id: 2,
          question: "高い___、買いました。",
          options: ["ものの", "のに", "が", "けど"],
          correctAnswer: 0,
          explanation: "ものの means 'although'."
        },
        {
          id: 3,
          question: "彼___限り、大丈夫です。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 1,
          explanation: "限り means 'as long as'."
        },
        {
          id: 4,
          question: "この件___関して質問があります。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に関して means 'regarding'."
        },
        {
          id: 5,
          question: "3日___に一回行きます。",
          options: ["ごと", "おき", "まで", "から"],
          correctAnswer: 1,
          explanation: "おきに means 'at intervals of'."
        }
      ]
    ]
  },
  {
    level: "N2",
    questions: [
      // Set 1
      [
        {
          id: 1,
          question: "忙しい___か、手伝ってくれました。",
          options: ["ばかり", "どころ", "上", "反面"],
          correctAnswer: 0,
          explanation: "ばかりか means 'not only but also'."
        },
        {
          id: 2,
          question: "彼が犯人に___ありません。",
          options: ["違い", "決まって", "ほか", "とって"],
          correctAnswer: 0,
          explanation: "に違いない means 'must be'."
        },
        {
          id: 3,
          question: "これ___きっかけに始めました。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 0,
          explanation: "をきっかけに means 'taking advantage of'."
        },
        {
          id: 4,
          question: "会議___際して、資料を準備します。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に際して means 'on the occasion of'."
        },
        {
          id: 5,
          question: "努力___にもかかわらず、失敗しました。",
          options: ["を", "が", "した", "する"],
          correctAnswer: 2,
          explanation: "にもかかわらず means 'despite'."
        }
      ],
      // Set 2
      [
        {
          id: 1,
          question: "日本語___おろか英語もできません。",
          options: ["が", "を", "は", "に"],
          correctAnswer: 2,
          explanation: "はおろか means 'let alone'."
        },
        {
          id: 2,
          question: "彼___にしては若く見えます。",
          options: ["を", "が", "の年", "に"],
          correctAnswer: 2,
          explanation: "にしては means 'considering'."
        },
        {
          id: 3,
          question: "ベルが鳴る___、走り出しました。",
          options: ["と同時に", "やいなや", "が最後", "とたんに"],
          correctAnswer: 1,
          explanation: "やいなや means 'as soon as'."
        },
        {
          id: 4,
          question: "経験___だけあって上手です。",
          options: ["を", "が", "した", "の"],
          correctAnswer: 1,
          explanation: "だけあって means 'being the case'."
        },
        {
          id: 5,
          question: "成功___ともに喜びました。",
          options: ["を", "が", "と", "に"],
          correctAnswer: 2,
          explanation: "とともに means 'together with'."
        }
      ],
      // Set 3
      [
        {
          id: 1,
          question: "規則___従ってください。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に従って means 'in accordance with'."
        },
        {
          id: 2,
          question: "見た___、判断できません。",
          options: ["だけで", "ばかりで", "ところで", "上で"],
          correctAnswer: 0,
          explanation: "だけで means 'just by'."
        },
        {
          id: 3,
          question: "データ___基づいて分析します。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 2,
          explanation: "に基づいて means 'based on'."
        },
        {
          id: 4,
          question: "静か___反面、不便です。",
          options: ["の", "な", "だ", "である"],
          correctAnswer: 1,
          explanation: "反面 means 'on the other hand'."
        },
        {
          id: 5,
          question: "努力___ばかりに失敗しました。",
          options: ["を", "が", "しない", "する"],
          correctAnswer: 2,
          explanation: "ばかりに means 'simply because'."
        }
      ]
    ]
  },
  {
    level: "N1",
    questions: [
      // Set 1
      [
        {
          id: 1,
          question: "学生___もの、勉強すべきだ。",
          options: ["たる", "なる", "である", "による"],
          correctAnswer: 0,
          explanation: "たるもの means 'one who is'."
        },
        {
          id: 2,
          question: "努力___して成功なし。",
          options: ["が", "を", "なく", "に"],
          correctAnswer: 2,
          explanation: "なくして means 'without'."
        },
        {
          id: 3,
          question: "彼___ならいざしらず、私には無理だ。",
          options: ["を", "が", "に", "なら"],
          correctAnswer: 3,
          explanation: "ならいざしらず means 'might be able to, but'."
        },
        {
          id: 4,
          question: "ベルが鳴る___か、走り出した。",
          options: ["が早い", "やいなや", "なり", "そばから"],
          correctAnswer: 0,
          explanation: "が早いか means 'the moment'."
        },
        {
          id: 5,
          question: "彼の発言___、問題が起きた。",
          options: ["ゆえに", "ために", "ので", "から"],
          correctAnswer: 0,
          explanation: "ゆえに means 'therefore' (formal)."
        }
      ],
      // Set 2
      [
        {
          id: 1,
          question: "成功___あってのことだ。",
          options: ["を", "が", "は", "あって"],
          correctAnswer: 3,
          explanation: "あっての means 'thanks to'."
        },
        {
          id: 2,
          question: "彼___おいて他にいない。",
          options: ["を", "が", "に", "で"],
          correctAnswer: 0,
          explanation: "をおいて means 'other than'."
        },
        {
          id: 3,
          question: "見る___ずにはいられない。",
          options: ["を", "が", "に", "て"],
          correctAnswer: 0,
          explanation: "ずにはいられない means 'cannot help but'."
        },
        {
          id: 4,
          question: "泣かん___に訴えた。",
          options: ["ばかり", "ほど", "くらい", "まで"],
          correctAnswer: 0,
          explanation: "んばかりに means 'as if about to'."
        },
        {
          id: 5,
          question: "彼女___ときたら、いつも遅れる。",
          options: ["を", "が", "と", "に"],
          correctAnswer: 2,
          explanation: "ときたら means 'when it comes to'."
        }
      ],
      // Set 3
      [
        {
          id: 1,
          question: "結果___いかんで決まる。",
          options: ["を", "が", "に", "の"],
          correctAnswer: 3,
          explanation: "いかんで means 'depending on'."
        },
        {
          id: 2,
          question: "努力___かたわら、趣味も楽しむ。",
          options: ["を", "が", "の", "に"],
          correctAnswer: 2,
          explanation: "かたわら means 'while, besides'."
        },
        {
          id: 3,
          question: "彼___ともあろう者が失敗した。",
          options: ["を", "が", "に", "と"],
          correctAnswer: 3,
          explanation: "ともあろう means 'someone of stature'."
        },
        {
          id: 4,
          question: "見た___、優しい人だ。",
          options: ["ところ", "だけ", "ばかり", "ほど"],
          correctAnswer: 0,
          explanation: "ところ can mean 'judging from'."
        },
        {
          id: 5,
          question: "申す___もなく重要だ。",
          options: ["まで", "ほど", "くらい", "だけ"],
          correctAnswer: 0,
          explanation: "申すまでもなく means 'needless to say'."
        }
      ]
    ]
  }
];
